  
     
<?php
$this->load->view('common/css_link');
$this->load->view('common/header');
$this->load->view('common/sidebar');
$this->load->view('common/control_panel');
?>
    
    <br/> 
    <br/> 
    <br/> 
    
<div class="alert alert-danger">
    <h2> Access Deny !! </h2>
</div>
    
    
<?php
$this->load->view('common/footer');

?>



     
 



