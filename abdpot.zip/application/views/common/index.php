<?php
include("header.php");
include("sidebar.php");
include("control_panel.php");
?>
    
    
    
    
    
    <h1>Content Area</h1>
    
    
    
    
<?php
include("footer.php");

?>


